package snippet;

public class Snippet {
	public static void main(String[] args) {
		/* BOTÓN DE REGISTRO */
		.register .action-button {
			position: absolute;
			right: -400px;
			bottom: 20px; 
			background : transparent;
			border: 1px solid rgb(255, 255, 255);
			border-radius: 40px;
			color: #fff;
			padding: .3rem .8rem;
			background: transparent;
		}
		/* BOTÓN DE REGISTRO */
	}
}

